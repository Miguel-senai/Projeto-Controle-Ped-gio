
        function calcularSalario() {
            // Obter valores do formulário
            const valorHora = parseFloat(document.getElementById('valorHora').value);
            const horasTrabalhadas = parseFloat(document.getElementById('horasTrabalhadas').value);
            const valeTransporte = document.getElementById('valeTransporte').value;
            const outrasDeducoes = parseFloat(document.getElementById('outrasDeducoes').value) || 0;
            
            // Calcular salário bruto
            const salarioBruto = valorHora * horasTrabalhadas;
            
            // Calcular dedução do vale-transporte (6% do salário bruto)
            const deducaoVT = valeTransporte === 'S' ? salarioBruto * 0.06 : 0;
            
            // Calcular salário líquido
            const salarioLiquido = salarioBruto - deducaoVT - outrasDeducoes;
           
            
            


           //Calcular Desconto do INSS
           let inss=0;
           if(salarioBruto <=1320)
              {
                inss = salarioBruto * 0.075;
                }
                else if (salarioBruto <= 2571.29)
                {
                inss = salarioBruto * 0.09;
                }
                else if (salarioBruto <= 3856.94)
                {
                inss = salarioBruto * 0.12;
                }
                else if (salarioBruto <= 7507.49)
                {
                inss = salarioBruto * 0.14;
                }
                else
                {
                inss = salarioBruto * 0.14;
                }
            //Calcular Desconto IRPF
            let irpf=0;
            salarioIrpf = salarioBruto - inss;
            
            

            if(salarioBruto <=2112.00)
            {
                  irpf = salarioIrpf * 0.0;
            }
            else if (salarioBruto <= 2826.65)
            {
                  irpf = salarioIrpf * 0.075 - deducaoVT;
            }
            else if (salarioBruto <= 3751.05)
            {
                  irpf = ssalarioIrpf * 0.15 - deducaoVT;
            }
            else if (salarioBruto <= 4664.68)
            {
                  irpf = salarioIrpf * 0.225 - deducaoVT;
            }
            else
            {
                  irpf = salarioIrpf * 0.275 - deducaoVT;
            }

           

            
            // Exibir resultados
            document.getElementById('salarioBruto').textContent = salarioBruto.toFixed(2);
           
           
            document.getElementById('deducaoVT').textContent = deducaoVT.toFixed(2);

            document.getElementById('outrasDeducoesResult').textContent = outrasDeducoes.toFixed(2);

            document.getElementById('salarioLiquido').textContent = salarioLiquido.toFixed(2);
            
            // Mostrar a seção de resultados
            document.getElementById('resultado').style.display = 'block';
        }
   